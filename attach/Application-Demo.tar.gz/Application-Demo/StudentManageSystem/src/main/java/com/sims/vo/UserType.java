package com.sims.vo;

public class UserType 
{
	private String userTypeId;
	
	private String userTypeName;
	
	private String userRight;
	
	private String UserDescription;

	public String getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getUserTypeName() {
		return userTypeName;
	}

	public void setUserTypeName(String userTypeName) {
		this.userTypeName = userTypeName;
	}

	public String getUserRight() {
		return userRight;
	}

	public void setUserRight(String userRight) {
		this.userRight = userRight;
	}

	public String getUserDescription() {
		return UserDescription;
	}

	public void setUserDescription(String userDescription) {
		UserDescription = userDescription;
	}
}
