package com.sims.util;

public class PrintUserPrivilege 
{
	public String printUserPrivilege(int[] pri)
	{
		String result = "";
		String content = null;
		if (pri[0]==1)
		{
			result = result+"信息管理、";
		}
		if (pri[1]==1)
		{
			result = result+"密码管理、";
		}
		if (pri[2]==1)
		{
			result = result+"权限管理";
		}
		char[] chararray = result.toCharArray();
		if(!result.equals("")&&chararray[chararray.length-1]=='、')
		{
			content = result.substring(0, chararray.length-1);
			return content;
		}
		else if(result.equals(""))
		{
			String nopriv = "无权限";
			return nopriv;			
		}
		else
		{
			return result;
		}
	}
}
