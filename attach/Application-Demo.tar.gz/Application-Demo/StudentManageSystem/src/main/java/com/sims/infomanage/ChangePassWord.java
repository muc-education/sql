package com.sims.infomanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;

public class ChangePassWord extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String oldPwd = request.getParameter("oldpwd");
			String newPwd = request.getParameter("newpwd");
			String userId=(String)request.getSession().getAttribute("username");
			UserDAO ud = new UserDAO();
			if(ud.checkUserPwd(userId, oldPwd))
			{
				ud.changePWD(userId, newPwd);
				request.getSession().setAttribute("currentPage", "1");
				response.sendRedirect("/sims/pages/default.jsp");
			}
			else
			{
				String errMsg = "�������ԭʼ�����������������룡";
				request.getSession().setAttribute("Message", errMsg);
				response.sendRedirect("/sims/pages/changepwd.jsp");
			}
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Change password fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Change password fail.");
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			System.out.println("Change password fail.");
			e.printStackTrace();
		}
		
	}
}
