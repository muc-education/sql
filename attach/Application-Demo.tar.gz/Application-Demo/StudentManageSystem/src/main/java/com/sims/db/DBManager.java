package com.sims.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBManager {
    //初始化数据库连接
    public Connection initDB() throws IOException {
        Connection con = null;
        try {
            java.util.Properties properties = new java.util.Properties();
            InputStream inputStream = this.getClass().getResourceAsStream("/jdbc.properties");
            if (inputStream != null) {
                properties.load(inputStream);

                // 根据Key取得配置文件中的值
                String classDriver = properties.getProperty("com.mysql.jdbc.Driver");
                String url = properties.getProperty("url");
                String username = properties.getProperty("username");
                String password = properties.getProperty("password");

                Class.forName(classDriver);
                con = DriverManager.getConnection(url, username, password);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }

    public void closeDB(Statement sm, Connection con) {
        //关闭数据路连接（无结果集）
        try {

            sm.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeDB(ResultSet rs, Statement sm, Connection con) {
        //关闭数据路连接（有结果集）
        try {

            rs.close();
            sm.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
