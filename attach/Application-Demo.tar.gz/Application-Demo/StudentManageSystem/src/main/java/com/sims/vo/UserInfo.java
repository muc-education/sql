package com.sims.vo;

public class UserInfo 
{
	private String userId;
	
	private String userName;
	
	private String userSex;
	
	private String userCollage;
	
	private String userSpecialty;
	
	private String userPwd;
	
	private String userTypeId;
	
	private String userDescription;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserSex() {
		return userSex;
	}

	public void setUserSex(String userSex) {
		this.userSex = userSex;
	}

	public String getUserCollage() {
		return userCollage;
	}

	public void setUserCollage(String userCollage) {
		this.userCollage = userCollage;
	}

	public String getUserSpecialty() {
		return userSpecialty;
	}

	public void setUserSpecialty(String userSpecialty) {
		this.userSpecialty = userSpecialty;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getUserDescription() {
		return userDescription;
	}

	public void setUserDescription(String userDescription) {
		this.userDescription = userDescription;
	}
}
