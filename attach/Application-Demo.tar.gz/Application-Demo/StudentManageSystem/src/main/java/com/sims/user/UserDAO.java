package com.sims.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.sims.db.DBManager;
import com.sims.vo.UserInfo;
import com.sims.vo.UserType;

public class UserDAO {
    //校验用户密码
    public boolean checkUserPwd(String userName, String userPassword) throws IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        UserInfo ui = new UserInfo();

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "select * from sims_userinfo where UserId = '" + userName + "'";
            rs = sm.executeQuery(sql);
            while (rs.next()) {
                //get passwd from db
                ui.setUserPwd(rs.getString("UserPwd"));
            }
        } catch (SQLException e) {
            System.out.println("Can't find user " + userName + " in DB.");
            e.printStackTrace();
        } finally {
            if (rs != null) {
                dm.closeDB(rs, sm, con);
            } else {
                dm.closeDB(sm, con);
            }
        }

        if (rs != null && ui.getUserPwd().equals(userPassword)) {
            return true;
        } else {
            return false;
        }
    }

    //修改用户密码
    public void changePWD(String userId, String userPWD) throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "update sims_userinfo set userpwd = '" + userPWD + "' where userid = '" + userId + "'";
        sm.executeUpdate(sql);

        dm.closeDB(sm, con);

    }

    //新增用户
    public void createUser(UserInfo userinfo) throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        String userId = userinfo.getUserId();
        String userName = userinfo.getUserName();
        String userSex = userinfo.getUserSex();
        String userCollage = userinfo.getUserCollage();
        String userSpecialty = userinfo.getUserSpecialty();
        String userTypeId = userinfo.getUserTypeId();
        String userDesc = userinfo.getUserDescription();
        String userPwd = userinfo.getUserPwd();

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "insert into sims_userinfo values ('" + userId + "','" + userName + "','" + userSex + "','" + userCollage + "','"
                + userSpecialty + "','" + userPwd + "','" + userTypeId + "','" + userDesc + "')";
        sm.executeUpdate(sql);

        dm.closeDB(sm, con);
    }

    //查询单个用户信息
    public UserInfo queryUserinfo(String userId) throws IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        UserInfo userInfo = new UserInfo();

        con = dm.initDB();
        try {
            sm = con.createStatement();
            String sql = "select * from sims_userinfo where userid = '" + userId + "'";
            rs = sm.executeQuery(sql);
            while (rs.next()) {
                userInfo.setUserId(rs.getString("userid"));
                userInfo.setUserName(rs.getString("username"));
                userInfo.setUserSex(rs.getString("usersex"));
                userInfo.setUserCollage(rs.getString("usercollage"));
                userInfo.setUserSpecialty(rs.getString("userspecialty"));
                userInfo.setUserTypeId(rs.getString("usertypeid"));
                userInfo.setUserDescription(rs.getString("userdescription"));
            }
        } catch (SQLException e) {
            System.out.println("Query userinfo fail.");
            e.printStackTrace();
        }

        dm.closeDB(rs, sm, con);
        return userInfo;
    }

    //查询用户信息表记录总数
    public String queryCount() throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        String count = null;

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "select count(*) from sims_userinfo";
        rs = sm.executeQuery(sql);
        while (rs.next()) {
            count = rs.getString("count(*)");
        }

        return count;
    }

    //根据当前分页查询用户信息
    public ArrayList<UserInfo> queryUserInfos(String currentCount) throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        ArrayList<UserInfo> infos = new ArrayList<UserInfo>();
        int startCount = (Integer.parseInt(currentCount) - 1) * 10;

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "select * from sims_userinfo order by userid limit " + startCount + ",10";
        rs = sm.executeQuery(sql);
        while (rs.next()) {
            UserInfo userinfo = new UserInfo();
            userinfo.setUserId(rs.getString("userid"));
            userinfo.setUserName(rs.getString("username"));
            userinfo.setUserSex(rs.getString("usersex"));
            userinfo.setUserCollage(rs.getString("usercollage"));
            userinfo.setUserSpecialty(rs.getString("userspecialty"));
            userinfo.setUserDescription(rs.getString("userdescription"));

            infos.add(userinfo);
        }

        dm.closeDB(rs, sm, con);

        return infos;
    }

    //查询所有用户信息
    public ArrayList<UserInfo> queryUserInfos() throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        ArrayList<UserInfo> infos = new ArrayList<UserInfo>();

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "select * from sims_userinfo order by userid";
        rs = sm.executeQuery(sql);
        while (rs.next()) {
            UserInfo userinfo = new UserInfo();
            userinfo.setUserId(rs.getString("userid"));
            userinfo.setUserName(rs.getString("username"));
            userinfo.setUserSex(rs.getString("usersex"));
            userinfo.setUserCollage(rs.getString("usercollage"));
            userinfo.setUserSpecialty(rs.getString("userspecialty"));
            userinfo.setUserDescription(rs.getString("userdescription"));

            infos.add(userinfo);
        }

        dm.closeDB(rs, sm, con);

        return infos;
    }

    public void saveUser(UserInfo userinfo) throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        String userId = userinfo.getUserId();
        String userName = userinfo.getUserName();
        String userSex = userinfo.getUserSex();
        String userCollage = userinfo.getUserCollage();
        String userSpecialty = userinfo.getUserSpecialty();
        String userTypeId = userinfo.getUserTypeId();
        String userDesc = userinfo.getUserDescription();

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "update sims_userinfo set username = '" + userName + "',userSex = '" + userSex + "',userCollage = '" + userCollage + "'," +
                "userSpecialty = '" + userSpecialty + "',userTypeId = '" + userTypeId + "',UserDescription = '" + userDesc + "'" +
                "where userid = '" + userId + "'";
        sm.executeUpdate(sql);

        dm.closeDB(sm, con);
    }

    //删除用户信息
    public void deleteUser(String userId) throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "delete from sims_userinfo where userid = '" + userId + "'";
        sm.executeUpdate(sql);

        dm.closeDB(sm, con);
    }

    //查询用户的角色名称
    public String queryTypeNameByUserId(String userId) throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        String userTypeName = null;

        con = dm.initDB();
        sm = con.createStatement();
        String sql = "select * from sims_usertype where usertypeid = (select usertypeid from sims_userinfo where userid = '"
                + userId + "')";
        rs = sm.executeQuery(sql);
        while (rs.next()) {
            userTypeName = rs.getString("usertypeid");
        }

        if (userTypeName != null) {
            dm.closeDB(rs, sm, con);
        } else {
            dm.closeDB(sm, con);
        }

        return userTypeName;
    }

    //根据用户名查询用户信息，用于session校验
    @SuppressWarnings("finally")
    public boolean checkUserInfo(String userName) {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        int num = 0;

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "select * from sims_userinfo where UserId = '" + userName + "'";
            rs = sm.executeQuery(sql);
            rs.next();
            num = rs.getRow();
        } catch (SQLException e) {
            System.out.println("Can't find user " + userName + " in DB.");
            e.printStackTrace();
        } finally {
            if (num > 0) {
                dm.closeDB(rs, sm, con);
                return true;
            } else {
                dm.closeDB(sm, con);
                return false;
            }
        }
    }

    //根据UserId，查询该用户的用户权限：信息管理、密码管理、权限管理
    @SuppressWarnings("finally")
    public int[] getUserPrive(String userName) {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        int[] userrights = new int[4];

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "select userright from sims_usertype where usertypeid = (select usertypeid" +
                    " from sims_userinfo where userid = '" + userName + "')";
            rs = sm.executeQuery(sql);
            while (rs.next()) {
                //get userright from db
                String userrightbak = rs.getString("userright");
                char[] userriggtchar = userrightbak.toCharArray();
                for (int i = 0; i < userriggtchar.length; i++) {
                    userrights[i] = Integer.parseInt(String.valueOf(userriggtchar[i]));
                }
            }
        } catch (SQLException e) {
            System.out.println("Can't find user " + userName + " in DB.");
            e.printStackTrace();
        } finally {
            dm.closeDB(rs, sm, con);
            return userrights;
        }
    }

    //查询用户类型表，根据UserTypeId返回相应的用户类型信息
    @SuppressWarnings("finally")
    public UserType queryUserType(String userTypeId) {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        UserType result = new UserType();

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "select * from sims_usertype where usertypeid = '" + userTypeId + "'";
            rs = sm.executeQuery(sql);
            while (rs.next()) {
                result.setUserTypeId(rs.getString("usertypeid"));
                result.setUserTypeName(rs.getString("usertypename"));
                result.setUserRight(rs.getString("userright"));
                result.setUserDescription(rs.getString("userdescription"));
            }
        } catch (SQLException e) {
            System.out.println("Can't find any userType in DB.");
            e.printStackTrace();
        } finally {
            dm.closeDB(rs, sm, con);
            return result;
        }
    }

    //查询用户类型表，返回所有用户类型信息
    @SuppressWarnings("finally")
    public ArrayList<UserType> queryRights() {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        ArrayList<UserType> rights = new ArrayList<UserType>();

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "select * from sims_usertype order by usertypeid";
            rs = sm.executeQuery(sql);
            while (rs.next()) {
                UserType right = new UserType();
                right.setUserTypeId(rs.getString("usertypeid"));
                right.setUserTypeName(rs.getString("usertypename"));
                right.setUserRight(rs.getString("userright"));
                right.setUserDescription(rs.getString("userdescription"));

                rights.add(right);
            }


        } catch (SQLException e) {
            System.out.println("Can't find any userType in DB.");
            e.printStackTrace();
        } finally {
            dm.closeDB(rs, sm, con);
            return rights;
        }
    }

    //查询userTypeId在数据库是否已经存在
    @SuppressWarnings("finally")
    public boolean queryRights(String userTypeId) {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        int num = 0;

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "select * from sims_usertype where usertypeid = '" + userTypeId + "'";
            rs = sm.executeQuery(sql);
            rs.next();
            num = rs.getRow();
        } catch (SQLException e) {
            System.out.println("Can't find any userType in DB.");
            e.printStackTrace();
        } finally {
            if (num > 0) {
                dm.closeDB(rs, sm, con);
                return true;
            } else {
                dm.closeDB(sm, con);
                return false;
            }
        }
    }

    //新增userType
    public void insertUserType(String userTypeId, String userTypeName, String rights, String userDesc) throws IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "insert into sims_usertype values ('" + userTypeId + "','" + userTypeName + "','" + rights + "','" + userDesc + "')";
            sm.executeUpdate(sql);
        } catch (SQLException e) {
            System.out.println("Insert new role into DB fail.");
            e.printStackTrace();
        } finally {
            dm.closeDB(sm, con);
        }
    }

    //update usertype
    public void updateRole(UserType usertype) throws SQLException, IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "update sims_usertype set usertypename = '" + usertype.getUserTypeName() + "',userright = '" + usertype.getUserRight() +
                    "',userdescription = '" + usertype.getUserDescription() + "' where usertypeid = '" + usertype.getUserTypeId() + "'";
            sm.executeUpdate(sql);
        } catch (SQLException e) {
            System.out.println("update usertype info fail.");
            e.printStackTrace();
        } finally {
            dm.closeDB(sm, con);
        }
    }

    //删除角色类型
    public void deleterole(String userTypeId) throws IOException {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;

        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "delete from sims_usertype where usertypeid = '" + userTypeId + "'";
            sm.execute(sql);
        } catch (SQLException e) {
            System.out.println("update usertype info fail.");
            e.printStackTrace();
        } finally {
            dm.closeDB(sm, con);
        }
    }

    //查询当前的角色类型是否有用户使用
    @SuppressWarnings("finally")
    public boolean queryUserInfoByType(String userTypeId) {
        DBManager dm = new DBManager();
        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        int num = 0;
        try {
            con = dm.initDB();
            sm = con.createStatement();
            String sql = "select userid from sims_userinfo where usertypeid = '" + userTypeId + "'";
            rs = sm.executeQuery(sql);
            rs.next();
            num = rs.getRow();
        } catch (SQLException e) {
            System.out.println("update usertype info fail.");
            e.printStackTrace();
        } finally {
            if (num > 0) {
                dm.closeDB(rs, sm, con);
                return true;
            } else {
                dm.closeDB(sm, con);
                return false;
            }
        }
    }
}
