package com.sims.test;

import com.sims.util.DataTypeChange;

public class DataChangeTest
{
	public static void main(String[] args)
	{
		DataTypeChange dc = new DataTypeChange();
		String[] str = {"pwd","right"};
		System.out.println(dc.stringArrayToString(str));
		
		int[] test = {0,0,0};
		String test1 = ""+test[0]+test[1]+test[2];
		System.out.println(test1);
		
		String test2 = "111";
		int[] test3 = dc.stringToIntArray(test2);
		for (int i=0;i<test3.length;i++)
		{
			System.out.println(test3[i]+",");
		}		
	}
}
