package com.sims.rolemanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;
import com.sims.util.DataTypeChange;
import com.sims.vo.UserType;

public class UpdateRole extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String userTypeId = request.getParameter("userTypeId");
			UserDAO ud = new UserDAO();
			//��ȡusertype�������ֶ���Ϣ
			UserType result = ud.queryUserType(userTypeId);
			//��ȡuserrightȨ��λ��Ϣ
			String userrightbak = result.getUserRight();
			DataTypeChange dtc = new DataTypeChange();
			int[] userrights = dtc.stringToIntArray(userrightbak);
			
			request.getSession().setAttribute("userType", result);
			request.getSession().setAttribute("userRights", userrights);
			request.getRequestDispatcher("/pages/updaterole.jsp").forward(request, response);
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Update role fail.");
			e.printStackTrace();
		} 
		catch (ServletException e) 
		{
			System.out.println("Update role fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Update role fail.");
			e.printStackTrace();
		}
	}
}
