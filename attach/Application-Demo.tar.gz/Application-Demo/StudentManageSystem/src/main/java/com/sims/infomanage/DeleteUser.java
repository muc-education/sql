package com.sims.infomanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;

public class DeleteUser extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			
			String userId = request.getParameter("userId");
			UserDAO ud = new UserDAO();
			
			ud.deleteUser(userId);
			if (ud.queryUserinfo(userId).getUserId() != null)
			{
				String msg = "ɾ���û���Ϣʧ�ܡ�";
				request.getSession().setAttribute("Message", msg);
				request.getSession().setAttribute("currentPage", "1");
				response.sendRedirect("/sims/pages/default.jsp");
			}
			else
			{
				String msg = "ɾ���û���Ϣ�ɹ���";
				request.getSession().setAttribute("Message", msg);
				request.getSession().setAttribute("currentPage", "1");
				response.sendRedirect("/sims/pages/default.jsp");
			}
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Delete user fail.");
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			System.out.println("Delete user fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Delete user fail.");
			e.printStackTrace();
		}
	}
}
