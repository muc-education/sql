package com.sims.login;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.*;

import com.sims.user.UserDAO;

public class UserLogin extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response) 
			throws IOException,ServletException
	{
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String userName = request.getParameter("username");
		String userPassword = request.getParameter("userpassword");
		UserDAO ud = new UserDAO();
		if (ud.checkUserPwd(userName, userPassword))
		{
			HttpSession session = request.getSession();
			int[] userrights = ud.getUserPrive(userName);
			session.setAttribute("username", userName);
			session.setAttribute("userrights", userrights);
			request.getSession().setAttribute("currentPage", "1");
			request.getRequestDispatcher("/pages/default.jsp").forward(request, response);
		}
		else
		{
			String errMsg = "��������ȷ���û�������";
			request.getSession().setAttribute("Message", errMsg);
			response.sendRedirect("/sims/index.jsp");
		}
	}
}
