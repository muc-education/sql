package com.sims.test;

import java.io.IOException;
import java.sql.SQLException;

import com.sims.user.UserDAO;
import com.sims.vo.UserInfo;
import com.sims.vo.UserType;

public class UserDAOTest 
{
	public static void main(String args[]) throws SQLException, IOException
	{
		UserDAO ud = new UserDAO();
		//ud.checkUserPwd("1001", "1");
		System.out.println(ud.checkUserPwd("1001", "3"));
		
		//
		System.out.println(ud.checkUserInfo("100449"));
		
		//
		int[] array = ud.getUserPrive("1001");
		for (int i=0;i<array.length;i++)
		{
		System.out.println(array[i]);
		}
		
		//
		System.out.println(ud.queryRights());
		System.out.println(ud.queryRights("4444"));
		
		//
		//ud.insertUserType("1111", "testadmin", "000", "testadmin");
		ud.changePWD("1001", "3");
//		System.out.println(ud.queryUserInfos());
		System.out.println(ud.queryTypeNameByUserId("1002"));
//		UserType usertype = new UserType();
//		usertype.setUserTypeId(5);
//		usertype.setUserTypeName("superman");
//		usertype.setUserRight("111");
//		usertype.setUserDescription("superman");
//		ud.updateRole(usertype);
//		
//		ud.deleterole("1001");
//		
//		System.out.println(ud.queryUserInfoByType("1"));
//		System.out.println(ud.queryUserInfoByType("999"));
		
//		UserInfo ui = new UserInfo();
//		ui.setUserId("20050101");
//		ui.setUserName("����");
//		ui.setUserSex("��");
//		ui.setUserCollage("ͨ�Ź���");
//		ui.setUserSpecialty("��Ϣ����");
//		ui.setUserTypeId("admin");
//		ui.setUserDescription("��Ϣ051");
//		ud.createUser(ui);
//		
//		System.out.println(ud.checkUserInfo("1004"));
//		System.out.println(ud.queryUserinfo("1009").getUserName());
		
		System.out.println(Integer.parseInt(ud.queryCount()));
	}
}
