package com.sims.rolemanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;

public class BatchDelete extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String[] usertypes = request.getParameterValues("c");
			
			UserDAO ud = new UserDAO();
			for (int i=0;i<usertypes.length;i++)
			{
				if(ud.queryUserInfoByType(usertypes[i]))
				{
					String errmsg = "��Ҫɾ���������д��ڱ���ǰ�û�ʹ�õĽ�ɫ���ͣ�";
					request.getSession().setAttribute("Message", errmsg);
					break;
				}
				else
				{
					ud.deleterole(usertypes[i]);
				}
			}
			response.sendRedirect("/sims/pages/right.jsp");
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Batch delete usertype fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Batch delete usertype fail.");
			e.printStackTrace();
		}		
	}
}
