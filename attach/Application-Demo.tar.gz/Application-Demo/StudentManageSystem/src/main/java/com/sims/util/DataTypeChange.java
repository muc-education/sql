package com.sims.util;

public class DataTypeChange 
{
	public String stringArrayToString(String[] str)
	{
		if(str!=null&&str.length>0)
		{
			int[] rightsarray = new int[3];
			String rightstring = null;
			
			for (int i = 0;i<str.length;i++)
			{
				if (str[i].equals("info"))
				{
					rightsarray[0] = 1;
				}
				if (str[i].equals("pwd"))
				{
					rightsarray[1] = 1;
				}
				if (str[i].equals("right"))
				{
					rightsarray[2] = 1;
				}
			}
			rightstring = ""+rightsarray[0]+rightsarray[1]+rightsarray[2];
			return rightstring;
		}
		else
		{
			return "";
		}
		
	}
	
	public int[] stringToIntArray(String str)
	{
		int[] rightsint = new int[3];
    	char[] rightschar = str.toCharArray();
		for (int y = 0; y < rightschar.length;y++)
		{
			rightsint[y] = Integer.parseInt(String.valueOf(rightschar[y]));
		}
		return rightsint;
	}
}
