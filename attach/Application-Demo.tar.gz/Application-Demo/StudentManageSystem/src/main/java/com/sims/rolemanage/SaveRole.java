package com.sims.rolemanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;
import com.sims.util.DataTypeChange;
import com.sims.vo.UserType;

public class SaveRole extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String userTypeId = request.getParameter("roleid");
			String userTypeName = request.getParameter("rolename");
			String[] userRights = request.getParameterValues("roleright");
			String userDesc = request.getParameter("roledesc");
			
			UserDAO ud = new UserDAO();
			DataTypeChange dc = new DataTypeChange();
			UserType usertype = new UserType();
			String rights = dc.stringArrayToString(userRights);
			
			usertype.setUserTypeId(userTypeId);
			usertype.setUserTypeName(userTypeName);
			usertype.setUserRight(rights);
			usertype.setUserDescription(userDesc);
			ud.updateRole(usertype);
			request.getRequestDispatcher("/pages/right.jsp").forward(request, response);
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Save usertype info fail.");
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			System.out.println("Save usertype info fail.");
			e.printStackTrace();
		} 
		catch (ServletException e) 
		{
			System.out.println("Save usertype info fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Save usertype info fail.");
			e.printStackTrace();
		}
		
		
	}
}
