package com.sims.rolemanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;

public class DeleteRole extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String userTypeId = request.getParameter("userTypeId");
			UserDAO ud = new UserDAO();
			if (ud.queryUserInfoByType(userTypeId))
			{
				String errmsg = "�ý�ɫ�����ѱ��û�ʹ�ã�����ɾ����ص��û���";
				request.getSession().setAttribute("Message", errmsg);
				response.sendRedirect("/sims/pages/right.jsp");
			}
			else
			{
				ud.deleterole(userTypeId);
				response.sendRedirect("/sims/pages/right.jsp");
			}
		}
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Delete usertype fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Delete usertype fail.");
			e.printStackTrace();
		}
		
	}
}
