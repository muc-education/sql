package com.sims.rolemanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;
import com.sims.util.DataTypeChange;

public class CreatRole extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			//��ȡrequest�еĲ���ֵ
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String userTypeId = request.getParameter("roleid");
			String userTypeName = request.getParameter("rolename");
			String[] userRights = request.getParameterValues("roleright");
			String userDesc = request.getParameter("roledesc");
			
			UserDAO ud = new UserDAO();
			int[] rightsarray = {0,0,0};
			//У��userTypeId�����ݿ��Ƿ��ظ�
			if (ud.queryRights(userTypeId))
			{
				String errMsg = "������Ľ�ɫ����Ѵ��ڣ�����������";
				request.getSession().setAttribute("Message", errMsg);
				response.sendRedirect("/sims/pages/creatrole.jsp");
			}
			else
			{
				DataTypeChange dtc = new DataTypeChange();
				String rights = dtc.stringArrayToString(userRights);
				ud.insertUserType(userTypeId, userTypeName, rights, userDesc);
				request.getRequestDispatcher("/pages/right.jsp").forward(request, response);
			}
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Creat new role failure.");
			e.printStackTrace();
		} catch (ServletException e) {
			System.out.println("Creat new role failure.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Creat new role failure.");
			e.printStackTrace();
		} 
	}
}
