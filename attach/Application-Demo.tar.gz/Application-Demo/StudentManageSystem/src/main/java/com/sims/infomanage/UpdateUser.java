package com.sims.infomanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;
import com.sims.vo.UserInfo;

public class UpdateUser extends HttpServlet 
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			
			String userId = request.getParameter("userId");
			UserInfo userInfo = new UserInfo();
			UserDAO ud = new UserDAO();
			
			userInfo = ud.queryUserinfo(userId);
			request.getSession().setAttribute("userInfo", userInfo);
			request.getSession().setAttribute("currentPage", "1");
			response.sendRedirect("/sims/pages/updateuser.jsp");
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Update userinfo fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Update userinfo fail.");
			e.printStackTrace();
		}
		
		
	}
}
