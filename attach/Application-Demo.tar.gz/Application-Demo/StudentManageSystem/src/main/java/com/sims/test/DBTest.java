package com.sims.test;

import com.sims.db.DBManager;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBTest 
{
	public static void main(String args[]) throws IOException
	{
		DBManager dm = new DBManager();
		Connection con = null;
		Statement sm = null;
		ResultSet rs = null;
		
		try
		{
			con = dm.initDB();
			sm = con.createStatement();
			String sql = "select * from sims_UserInfo";
			rs = sm.executeQuery(sql);
			System.out.println(rs);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			dm.closeDB(rs, sm, con);
		}
	}
}
