package com.sims.infomanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;
import com.sims.vo.UserInfo;

public class CreateUser extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String userId = request.getParameter("userid");
			String userName = request.getParameter("username");
			String userSexValue = request.getParameter("usersex");
			String userCollage = request.getParameter("usercollage");
			String userSpecialty = request.getParameter("userspecialty");
			String userTypeId = request.getParameter("usertype");
			String userDescription = request.getParameter("userdesc");
			String userSex = null;
			UserDAO ud = new UserDAO();
			UserInfo userInfo = new UserInfo();
			
			//ת��userSexȡֵ
			if(userSexValue.equals("male"))
			{
				userSex = "��";
			}
			else
			{
				userSex = "Ů";
			}
			
			if (ud.checkUserInfo(userId))
			{
				//�ж�userid�Ƿ��Ѿ�����
				String errMsg = "�������ѧ���Ѵ��ڣ����������룡";
				request.getSession().setAttribute("Message", errMsg);
				response.sendRedirect("/sims/pages/creatuser.jsp");
			}
			else
			{
				userInfo.setUserId(userId);
				userInfo.setUserName(userName);
				userInfo.setUserSex(userSex);
				userInfo.setUserCollage(userCollage);
				userInfo.setUserSpecialty(userSpecialty);
				userInfo.setUserTypeId(userTypeId);
				userInfo.setUserDescription(userDescription);
				userInfo.setUserPwd(userId);
				ud.createUser(userInfo);
				request.getSession().setAttribute("currentPage", "1");
				response.sendRedirect("/sims/pages/default.jsp");
			}
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Create user fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Create user fail.");
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			System.out.println("Create user fail.");
			e.printStackTrace();
		}
	}
}
