package com.sims.infomanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;

public class BatchDeleteUser extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String[] users = request.getParameterValues("userc");
			String userId=(String)request.getSession().getAttribute("username");
			
			UserDAO ud = new UserDAO();
			for (int i=0;i<users.length;i++)
			{
				if(users[i].equals(userId))
				{
					String msg = "无法删除当前登录的用户！";
					request.getSession().setAttribute("Message", msg);
					break;
				}
				else
				{
					ud.deleteUser(users[i]);
					String msg = "批量删除用户信息成功！";
				}	
			}
			response.sendRedirect("/sims/pages/default.jsp");
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Batch delete user fail.");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Batch delete user fail.");
			e.printStackTrace();
		} catch (SQLException e) 
		{
			System.out.println("Batch delete user fail.");
			e.printStackTrace();
		}		
	}
}
