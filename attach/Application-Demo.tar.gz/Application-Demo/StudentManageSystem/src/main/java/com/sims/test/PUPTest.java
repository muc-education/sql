package com.sims.test;

import com.sims.util.PrintUserPrivilege;

public class PUPTest 
{
	public static void main(String[] args)
	{
		PrintUserPrivilege pup = new PrintUserPrivilege();
		int[] test = {1,0,0};
		System.out.println(pup.printUserPrivilege(test));
		
		System.out.println((11/2)+1);
	}
}
