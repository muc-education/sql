package com.sims.infomanage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sims.user.UserDAO;

public class ChangePage extends HttpServlet 
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			
			String currentPage = request.getParameter("cpage");
			request.getSession().setAttribute("currentPage", currentPage);
			response.sendRedirect("/sims/pages/default.jsp");
		} 
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("Delete user fail.");
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			System.out.println("Delete user fail.");
			e.printStackTrace();
		}
	}
}
