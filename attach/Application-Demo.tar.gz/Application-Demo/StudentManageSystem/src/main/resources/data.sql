//新建userinfo表
create table sims_UserInfo(
UserId varchar(20) not null primary key,
UserName varchar(20),
UserSex varchar(1),
UserCollage varchar(20),
UserSpecialty varchar(20),
UserPwd varchar(8),
UserDescription varchar(20)
);

//新建uusertype表
create table sims_UserType(
UserTypeId varchar (10) not null primary key,
UserTypeName varchar (20),
UserRight varchar (10),
UserDescription varchar(20)
);

//初始数据
insert into sims_UserType value ('admin','管理员','111','admin');
insert into sims_UserType value ('student','学生','110','student');
insert into sims_UserInfo value ('admin','admin','男','管理员','管理员','admin','admin','admin');

