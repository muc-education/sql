function check_all(obj,cName) 
{ 
	var checkboxs = document.getElementsByName(cName); 
	for(var i=0;i<checkboxs.length;i++)
	{
		checkboxs[i].checked = obj.checked;
	} 
}

function deleteUserType(usertypeid) 
{ 
	if(confirm("ȷ��ɾ����¼��"))
	{ 
		document.forms[0].action = "deleterole.do?userTypeId="+usertypeid; 
		document.forms[0].submit();
	}
	else
	{
		return false;
	}
}

function batchDelete(cName) 
{ 
	var checkboxs=document.getElementsByName(cName);
	var y=0;
	
	for(var i=0;i<checkboxs.length;i++)
	{
		if(checkboxs[i].checked==true)
		{
		y=y+1;
		}
	}
	
	if(y==0)
	{
		alert("��ѡ����Ҫɾ���ļ�¼��");
		return false;
	}
	else
	{
		if(confirm("ȷ��ɾ��"+y+"����¼��"))
		{ 
			document.forms[0].action = "batchdelete.do";
			document.forms[0].submit();
		}
		else
		{
			return false;
		}
	}
}

function checkUserType()
{
	var reg = new RegExp("^[A-Za-z0-9]+$");
  var obj = document.getElementById("roleid");
  if(!reg.test(obj.value))
  {
  	alert("���������ֺ�Ӣ���ַ�!");
  }
  else
  {
  	return true;
  }
}

function validate_pwdconfirm(pwd,pwdcf,alerttxt)
{
	if (pwd.value!=pwdcf.value) 
  {
  	alert(alerttxt);
  	return false
  }
	else 
	{
		return true
	}
}

function validate_form(thisform)
{
	with (thisform)
	{
		if (validate_pwdconfirm(newpwd,pwdconfirm,"������������벻һ�£����������룡")==false)
  	{
  		newpwd.focus();
  		return false
  	}
	}
}

function deleteUserInfo(UserId) 
{ 
	if(confirm("ȷ��ɾ����¼��"))
	{ 
		document.forms[0].action = "/sims/pages/deleteuser.do?userId="+UserId; 
		document.forms[0].submit();
	}
	else
	{
		return false;
	}
}

function batchDeleteUser(cName) 
{ 
	var checkboxs=document.getElementsByName(cName);
	var y=0;
	
	for(var i=0;i<checkboxs.length;i++)
	{
		if(checkboxs[i].checked==true)
		{
		y=y+1;
		}
	}
	
	if(y==0)
	{
		alert("��ѡ����Ҫɾ���ļ�¼��");
		return false;
	}
	else
	{
		if(confirm("ȷ��ɾ��"+y+"����¼��"))
		{ 
			document.forms[0].action = "/sims/pages/batchdeleteuser.do";
			document.forms[0].submit();
		}
		else
		{
			return false;
		}
	}
}

